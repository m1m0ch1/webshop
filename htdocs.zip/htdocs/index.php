<?php
require_once "api.php";
require_once "connect.php";

?>

<html>
  <head>
  
  </head>

  <body>

    <h1>Webshop</h1>

    <a href="/admin/"> Admin felület megnyitása </a>

    <p>Az admin bejelntkezés: admin@admin.hu és a jelszó: Admin</p  >

    <h3>API végpontok:</h3>

    <a href="api.php?tabla=products">products</a>
    <a href="api.php?tabla=purchase">purchase</a>
    <a href="api.php?tabla=categories">categories</a>

    <p>API végpont tesztelése HTML+Javascript segítségével:</p>

    <a href="index.html">index.html</a>
    
    
  </body>
  
</html>
